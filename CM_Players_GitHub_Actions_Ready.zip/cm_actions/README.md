# CM Players Android App

This is an Android Studio WebView app for the CM Players marketplace.

## Important
The marketplace uses the Node/Express backend from the main website project. An APK cannot run that Node server by itself.

1. Deploy the `cm_players_market` website/backend to a Node.js host with persistent storage.
2. Open `app/src/main/java/com/cmplayers/market/MainActivity.java`.
3. Replace:
   `https://YOUR-DOMAIN-HERE.example/`
   with your real HTTPS website address.
4. Open this folder in Android Studio.
5. Build > Build APK(s).

The app supports:
- Website navigation
- UPI links opening in installed UPI apps
- Photo/video upload chooser for the admin panel
- Back navigation

For production, use HTTPS and change the website's admin password.
