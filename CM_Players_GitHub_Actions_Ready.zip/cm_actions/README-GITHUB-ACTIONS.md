# CM Players — Phone se APK build

Is project ko GitHub par upload karke bina Android Studio ke APK build kiya ja sakta hai.

## Steps
1. GitHub par new repository banao.
2. Is ZIP ko extract karke **saari files/folders** repository me upload karo.
3. Ensure karo ki `.github/workflows/build-apk.yml` bhi upload hua hai.
4. GitHub me **Actions** tab kholo.
5. **Build CM Players APK** workflow select karo.
6. **Run workflow** dabao (ya `main` par push ke baad automatic build hoga).
7. Build complete hone par workflow ke **Artifacts** section me `CM-Players-debug-APK` download karo.

> Ye debug APK hai. Users ko bhejne se pehle website URL `app/src/main/java/com/cmplayers/market/MainActivity.java` me apne live HTTPS URL se replace karo.
