const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "change-this-password";

const ROOT = __dirname;
const DATA = path.join(ROOT, "data");
const UPLOADS = path.join(ROOT, "public", "uploads");
const LISTINGS_FILE = path.join(DATA, "listings.json");
const ORDERS_FILE = path.join(DATA, "orders.json");

fs.mkdirSync(DATA, { recursive: true });
fs.mkdirSync(UPLOADS, { recursive: true });

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch { return fallback; }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

if (!fs.existsSync(LISTINGS_FILE)) writeJson(LISTINGS_FILE, []);
if (!fs.existsSync(ORDERS_FILE)) writeJson(ORDERS_FILE, []);

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, UPLOADS),
  filename: (_, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${crypto.randomBytes(5).toString("hex")}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 80 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const allowed = [
      "image/jpeg", "image/png", "image/webp",
      "video/mp4", "video/webm", "video/quicktime"
    ];
    cb(null, allowed.includes(file.mimetype));
  }
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(ROOT, "public")));

const adminTokens = new Set();

function requireAdmin(req, res, next) {
  const token = req.headers["x-admin-token"];
  if (!token || !adminTokens.has(token)) {
    return res.status(401).json({ error: "Admin login required" });
  }
  next();
}

app.get("/api/listings", (req, res) => {
  const listings = readJson(LISTINGS_FILE, []);
  res.json(listings.filter(x => x.status !== "sold"));
});

app.post("/api/admin/login", (req, res) => {
  const { password } = req.body || {};
  if (!password || password !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Wrong password" });
  }
  const token = crypto.randomBytes(32).toString("hex");
  adminTokens.add(token);
  res.json({ token });
});

app.get("/api/admin/listings", requireAdmin, (req, res) => {
  res.json(readJson(LISTINGS_FILE, []));
});

app.post("/api/admin/listings", requireAdmin, upload.fields([
  { name: "images", maxCount: 10 },
  { name: "video", maxCount: 3 }
]), (req, res) => {
  const { title, description, price, uid, category } = req.body;
  if (!title || !price) return res.status(400).json({ error: "Title and price are required" });

  const images = (req.files?.images || []).map(f => `/uploads/${f.filename}`);
  const videos = (req.files?.video || []).map(f => `/uploads/${f.filename}`);

  const listings = readJson(LISTINGS_FILE, []);
  const item = {
    id: crypto.randomUUID(),
    title: String(title).trim(),
    description: String(description || "").trim(),
    price: Number(price),
    uid: String(uid || "").trim(),
    category: String(category || "Free Fire").trim(),
    images,
    videos,
    status: "available",
    createdAt: new Date().toISOString()
  };
  listings.unshift(item);
  writeJson(LISTINGS_FILE, listings);
  res.json(item);
});

app.delete("/api/admin/listings/:id", requireAdmin, (req, res) => {
  const listings = readJson(LISTINGS_FILE, []);
  const item = listings.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Listing not found" });

  [...(item.images || []), item.video].filter(Boolean).forEach(url => {
    const file = path.join(ROOT, "public", url.replace(/^\//, ""));
    if (fs.existsSync(file)) fs.unlinkSync(file);
  });

  writeJson(LISTINGS_FILE, listings.filter(x => x.id !== req.params.id));
  res.json({ ok: true });
});

app.get("/api/admin/orders", requireAdmin, (req, res) => {
  res.json(readJson(ORDERS_FILE, []));
});

app.patch("/api/admin/orders/:id", requireAdmin, (req, res) => {
  const orders = readJson(ORDERS_FILE, []);
  const order = orders.find(x => x.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found" });

  const allowed = ["pending", "verified", "rejected", "delivered"];
  if (allowed.includes(req.body.status)) order.status = req.body.status;
  order.updatedAt = new Date().toISOString();
  writeJson(ORDERS_FILE, orders);
  res.json(order);
});

const paymentUpload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    cb(null, ["image/jpeg", "image/png", "image/webp"].includes(file.mimetype));
  }
});

app.post("/api/orders", paymentUpload.single("paymentScreenshot"), (req, res) => {
  const { listingId, name, whatsapp, utr } = req.body;
  if (!listingId || !name || !whatsapp || !utr) {
    return res.status(400).json({ error: "Listing, name, WhatsApp and UTR are required" });
  }

  const listings = readJson(LISTINGS_FILE, []);
  const listing = listings.find(x => x.id === listingId && x.status !== "sold");
  if (!listing) return res.status(404).json({ error: "Listing is no longer available" });

  const orders = readJson(ORDERS_FILE, []);
  const order = {
    id: `CMP-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`,
    listingId: listing.id,
    listingTitle: listing.title,
    amount: listing.price,
    name: String(name).trim(),
    whatsapp: String(whatsapp).trim(),
    utr: String(utr).trim(),
    paymentScreenshot: req.file ? `/uploads/${req.file.filename}` : "",
    status: "pending",
    createdAt: new Date().toISOString()
  };

  orders.unshift(order);
  writeJson(ORDERS_FILE, orders);
  res.json({ ok: true, orderId: order.id });
});

app.get("/admin", (_, res) => {
  res.sendFile(path.join(ROOT, "public", "admin.html"));
});

app.get("*", (_, res) => {
  res.sendFile(path.join(ROOT, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`CM Players Market running on port ${PORT}`);
});
