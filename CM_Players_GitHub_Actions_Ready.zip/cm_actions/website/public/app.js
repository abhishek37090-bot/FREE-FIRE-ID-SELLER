let listings = [];
const $ = s => document.querySelector(s);
const money = n => `₹${Number(n).toLocaleString("en-IN")}`;

async function loadListings(){
  const r = await fetch("/api/listings");
  listings = await r.json();
  renderListings();
}
function renderListings(){
  const q = ($("#search")?.value || "").toLowerCase();
  const items = listings.filter(x => `${x.title} ${x.description} ${x.uid}`.toLowerCase().includes(q));
  const grid = $("#listingGrid");
  grid.innerHTML = "";
  $("#empty").classList.toggle("hidden", items.length > 0);
  items.forEach(item => {
    const img = item.images?.[0] || "";
    grid.insertAdjacentHTML("beforeend", `
      <article class="card">
        <div class="thumb">
          ${img ? `<img src="${img}" alt="${esc(item.title)}">` : `<div style="height:100%;display:grid;place-items:center;font-size:55px">🎮</div>`}
          ${item.video ? `<span class="video-badge">▶ Video</span>` : ""}
        </div>
        <div class="card-body">
          <h3>${esc(item.title)}</h3>
          <div class="muted small">${esc(item.uid ? "UID: "+item.uid : "Free Fire account")}</div>
          <div class="price">${money(item.price)}</div>
          <div class="card-actions">
            <button class="ghost-btn" onclick="showDetails('${item.id}')">View</button>
            <button class="buy-btn" onclick="showPayment('${item.id}')">Buy</button>
          </div>
        </div>
      </article>`);
  });
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function showDetails(id){
  const x=listings.find(a=>a.id===id); if(!x)return;
  let media=x.images?.[0]?`<img id="mainMedia" src="${x.images[0]}" alt="">`:`<div style="padding:100px;text-align:center">No image</div>`;
  if(x.video) media += `<video controls style="margin-top:10px"><source src="${x.video}"></video>`;
  const thumbs=(x.images||[]).map(u=>`<img src="${u}" onclick="document.getElementById('mainMedia').src='${u}'">`).join("");
  $("#details").innerHTML=`<div class="detail-grid"><div><div class="media-main">${media}</div><div class="thumbs">${thumbs}</div></div><div><p class="eyebrow">ACCOUNT DETAILS</p><h2>${esc(x.title)}</h2><p class="muted">${esc(x.description||"Account showcase listing.")}</p><div class="notice">UID: ${esc(x.uid||"Not provided")}<br>Category: ${esc(x.category||"Free Fire")}</div><div class="price">${money(x.price)}</div><button class="buy-btn" style="width:100%;padding:14px" onclick="closeModal('detailsModal');showPayment('${x.id}')">Buy this account</button><p class="small muted" style="margin-top:15px">Delivery is handled manually after payment verification.</p></div></div>`;
  openModal("detailsModal");
}
function showPayment(id){
  const x=listings.find(a=>a.id===id); if(!x)return;
  const upi=`upi://pay?pa=shivanikumar456328@fam&pn=CM%20Players&am=${encodeURIComponent(x.price)}&cu=INR`;
  $("#payment").innerHTML=`<div class="pay-layout"><p class="eyebrow">SECURE PAYMENT STEP</p><h2>Pay ${money(x.price)}</h2><p class="muted">${esc(x.title)}</p><img src="/qr.png" alt="UPI QR code"><a class="upi" href="${upi}">Open UPI app → shivanikumar456328@fam</a><div class="notice">1. Scan the QR / pay using the UPI button.<br>2. Complete payment.<br>3. Enter your UTR/reference number below.<br>4. Submit the order. Your payment is manually checked.</div><form class="form" id="orderForm"><input type="hidden" name="listingId" value="${x.id}"><input name="name" required placeholder="Your name"><input name="whatsapp" required placeholder="WhatsApp number"><input name="utr" required placeholder="UPI UTR / transaction reference"><label>Payment screenshot (optional)<input type="file" name="paymentScreenshot" accept="image/*"></label><button class="submit">Submit payment proof</button><div id="formMsg" class="small"></div></form></div>`;
  $("#orderForm").onsubmit=submitOrder;
  openModal("paymentModal");
}
async function submitOrder(e){
  e.preventDefault(); const f=e.target, msg=$("#formMsg"); msg.textContent="Submitting...";
  const fd=new FormData(f);
  try{
    const r=await fetch("/api/orders",{method:"POST",body:fd}), d=await r.json();
    if(!r.ok) throw new Error(d.error||"Could not submit");
    f.innerHTML=`<div class="success"><h3>Order submitted ✅</h3><p>Your order ID is <b>${esc(d.orderId)}</b>.</p><p class="muted">Keep this ID and your UTR. The seller will verify the payment and contact you for delivery.</p></div>`;
  }catch(err){msg.className="small error";msg.textContent=err.message}
}
function openModal(id){$("#"+id).classList.remove("hidden")}
function closeModal(id){$("#"+id).classList.add("hidden")}
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>closeModal(b.dataset.close));
document.querySelectorAll(".modal").forEach(m=>m.addEventListener("click",e=>{if(e.target===m)m.classList.add("hidden")}));
$("#search").addEventListener("input",renderListings);
$("#year").textContent=new Date().getFullYear();
loadListings();
