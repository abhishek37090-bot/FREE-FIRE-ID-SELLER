# CM Players Market

A deployable Node.js/Express website for listing gaming accounts with photos, videos, UPI QR payment and manual order verification.

## Included
- Public marketplace at `/`
- Account cards with up to 10 photos and up to 3 videos
- Buy flow with UPI QR and UPI deep link
- Buyer name, WhatsApp, UTR and optional payment screenshot
- Admin panel at `/admin`
- Admin panel can add/delete listings, upload up to 10 photos + 3 videos per listing, and update order status
- JSON storage (simple, suitable for a small deployment)

## Run locally
1. Install Node.js 18+.
2. Open this folder in a terminal.
3. Run:
   `npm install`
4. Set an admin password:
   - Windows PowerShell: `$env:ADMIN_PASSWORD="your-strong-password"`
   - Linux/macOS: `export ADMIN_PASSWORD="your-strong-password"`
5. Start:
   `npm start`
6. Open `http://localhost:3000`
7. Admin: `http://localhost:3000/admin`

## Important payment note
The QR supplied in this project is the uploaded FamX QR image, cropped for the payment section. QR/UPI payment is NOT automatically verified. The buyer submits the UTR and optional screenshot; the admin manually verifies the payment before delivery.

## Deploy
This project can be deployed to a Node.js host that supports persistent storage. If the host has an ephemeral filesystem, move uploads/orders/listings to a real database/object storage before production.

## Security
Change `ADMIN_PASSWORD` before deployment. For a larger production site, use a real database, HTTPS, rate limiting, stronger admin sessions, and a proper payment gateway/webhook.
